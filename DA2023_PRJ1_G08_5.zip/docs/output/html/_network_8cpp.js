var _network_8cpp =
[
    [ "comparevp", "_network_8cpp.html#ab11a03aca5e7b7cf81d4a8af95293d40", null ],
    [ "sortbysec", "_network_8cpp.html#a3e5efe938b8b78795a0e24a431ad5498", null ]
];