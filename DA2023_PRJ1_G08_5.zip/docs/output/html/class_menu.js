var class_menu =
[
    [ "Menu", "class_menu.html#ad466dd83355124a6ed958430450bfe94", null ],
    [ "basicMaxFlow", "class_menu.html#a5f013d0ccc77933fb0635d592664e1dd", null ],
    [ "basicMaxFlowIntireGrid", "class_menu.html#a958c8b0a6d60d149f55d2eecc39eac86", null ],
    [ "basicMostBusy", "class_menu.html#a109e7a0c6501b9b0944d05bc4c117a99", null ],
    [ "basicMostImportant", "class_menu.html#a6227e23c0b18ab692534512536f7b2e4", null ],
    [ "basicServiceMenu", "class_menu.html#ae2f61f906d8dd4711ae1ac34f1f2a3e1", null ],
    [ "costOptimizationDisplay", "class_menu.html#a5e78e903ac5e50d1d6b258a4867c800b", null ],
    [ "failuresMaxFlow", "class_menu.html#a4332230451471e7fe071367dc72c7788", null ],
    [ "failuresReport", "class_menu.html#aec225ec56492dda7ab39cf5578e5440d", null ],
    [ "lineFailuresMenu", "class_menu.html#a40283fd5e421902c881ec61ba08a8f6c", null ],
    [ "mainMenu", "class_menu.html#a58127793dea8ce30bfaf2ee7c80f1dd1", null ],
    [ "randomGenerateRailway", "class_menu.html#a042cecb87c29fdd5cadf0bd1b08d26cf", null ],
    [ "receiveStation", "class_menu.html#a52e27923bc039269ee2dda5c81ddb95f", null ],
    [ "removeConnectionsRailway", "class_menu.html#ab497917f1796d99a9be02e2f6de4cac1", null ],
    [ "setUpCustom", "class_menu.html#af913806c346ef75ea5aa56b036029f2f", null ],
    [ "setUpMenu", "class_menu.html#a8737bc9e47bc898aa243d76d6c065ec6", null ],
    [ "setUpSubRailway", "class_menu.html#a5ee2a09fb27a2355d0d31ff5d00852ce", null ],
    [ "setUpTrainPricesMenu", "class_menu.html#adfed616ddd08f1defa3e7e9c876cc8a3", null ],
    [ "dataPath", "class_menu.html#acffe4292c9ed6bfc160c28685ac19565", null ],
    [ "railway", "class_menu.html#ae38ce5f8afe68a4dc332f023b05a82a3", null ],
    [ "subrailway", "class_menu.html#ad54d90dc79c7298fb80ed27c8122af74", null ]
];