var searchData=
[
  ['linefailuresmenu_0',['lineFailuresMenu',['../class_menu.html#a40283fd5e421902c881ec61ba08a8f6c',1,'Menu']]],
  ['linefailuresmenuprinter_1',['lineFailuresMenuPrinter',['../class_menu.html#a6162e25338371d30553c2d2ef7209984',1,'Menu']]]
];
