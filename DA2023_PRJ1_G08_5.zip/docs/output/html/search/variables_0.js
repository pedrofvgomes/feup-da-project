var searchData=
[
  ['capacity_0',['capacity',['../class_connection.html#a2c8e858b020fe5a5d26ee8054e6e7573',1,'Connection']]],
  ['connections_1',['connections',['../class_station.html#a5268cec43c52a4f9647e1c758413c20f',1,'Station']]]
];
