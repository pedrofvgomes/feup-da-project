var searchData=
[
  ['visited_0',['visited',['../class_station.html#a5c1636c3bc53579499c97bf41e02a3c5',1,'Station']]]
];
