var searchData=
[
  ['testandvisit_0',['testAndVisit',['../class_network.html#abf8744a8d3e6ef3454acf069a367f405',1,'Network']]],
  ['topkdistricts_1',['topKDistricts',['../class_network.html#aac5fb2444cb36144195f7ac1c9a8ccf1',1,'Network']]],
  ['topkmunicipalities_2',['topKMunicipalities',['../class_network.html#a0c12582c48bb3de526153a503a2119a5',1,'Network']]]
];
