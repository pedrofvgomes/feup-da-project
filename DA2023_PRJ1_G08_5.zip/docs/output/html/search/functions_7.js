var searchData=
[
  ['isselected_0',['isSelected',['../class_connection.html#a2802a6477978ac40d7beaa817690da9c',1,'Connection']]],
  ['isstationoutputsafe_1',['isStationOutputSafe',['../class_menu.html#a6e740c1b53447a7753988bd8f048029e',1,'Menu']]],
  ['isvisited_2',['isVisited',['../class_station.html#a3eee49988559a4a26fa715f3fc44beac',1,'Station']]]
];
