var searchData=
[
  ['addbidirectionalconnection_0',['addBidirectionalConnection',['../class_network.html#aa0a0e40729ad79dc6e7ff206a3ba22b4',1,'Network::addBidirectionalConnection()'],['../class_station.html#aaaeece0d894dc57c47808aebdfae3bf1',1,'Station::addBidirectionalConnection(Station *destination, int capacity, std::string &amp;service)']]],
  ['addconnection_1',['addConnection',['../class_station.html#a8e1d8e7f9d698e4d460220a6016fa9ed',1,'Station']]],
  ['addstation_2',['addStation',['../class_network.html#a1b8defbc69537c940ffc3ba24c14fe57',1,'Network']]],
  ['augmentflowalongpath_3',['augmentFlowAlongPath',['../class_network.html#aa347a2285d94fb8efab8f512ab185097',1,'Network']]]
];
