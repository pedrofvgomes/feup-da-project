var searchData=
[
  ['railway_0',['railway',['../class_menu.html#ae38ce5f8afe68a4dc332f023b05a82a3',1,'Menu']]],
  ['reverse_1',['reverse',['../class_connection.html#a9f6fa8ddaf0a3c9c4838a0dd5e94ee24',1,'Connection']]]
];
