var searchData=
[
  ['origin_0',['origin',['../class_connection.html#a4a7238c707c58f94c1159ff475fa9f6c',1,'Connection']]]
];
