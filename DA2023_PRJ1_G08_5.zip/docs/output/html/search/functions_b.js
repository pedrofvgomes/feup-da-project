var searchData=
[
  ['pressentertocontinue_0',['pressEnterToContinue',['../class_menu.html#a80117d3e6e7adc501358545098f6fdba',1,'Menu']]],
  ['pressentertoreturn_1',['pressEnterToReturn',['../class_menu.html#a52514dd8d45c8b0ae23eb1bb35720af1',1,'Menu']]]
];
