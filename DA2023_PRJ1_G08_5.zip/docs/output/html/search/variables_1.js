var searchData=
[
  ['datapath_0',['dataPath',['../class_menu.html#acffe4292c9ed6bfc160c28685ac19565',1,'Menu']]],
  ['destination_1',['destination',['../class_connection.html#af2c82d4b702318b47604994befa761cd',1,'Connection']]],
  ['dist_2',['dist',['../class_station.html#a708c8cbda29ed04a7a4f8a1e558130bc',1,'Station']]],
  ['district_3',['district',['../class_station.html#a0d07e5afc43d0a34ad02bc0801914de7',1,'Station']]]
];
